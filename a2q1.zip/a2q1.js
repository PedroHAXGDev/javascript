function obterEntrada(){
    var valido = Number(document.getElementById("valido").value);
    var branco = Number(document.getElementById("branco").value);
    var nulo = Number(document.getElementById("nulo").value);
    var total = Number(document.getElementById("total").value);
    if ((valido+branco+nulo!=total)){
            document.write("Numero total diferente da soma dos 3 valores!");
    }else{document.write((valido/total)*100 +"% de validos, ");
          document.write((branco/total)*100 +"% de brancos e ");
          document.write((nulo/total)*100 +"% de nulos"); 

    }
}