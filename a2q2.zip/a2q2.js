function obterEntrada(){
    var maca = Number(document.getElementById("maca").value);
    if ((maca < 12)){
        document.write(maca*1.3 +" Reais")
    }else{(document.write(maca+ " Reais"))
    }
}